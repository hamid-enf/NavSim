# Navigation Simulator (GNSS/INS Educational Lab)

شبیه‌ساز کاملاً **تعاملی، گرافیکی و آموزشی** Navigation در متلب:
جریان کامل داده از **Sensor** تا **Navigation Solution** به‌صورت زنده قابل مشاهده است
و پارامترهای سیستم در **Runtime** قابل تغییرند.

```
Trajectory → Truth → IMU ─┐                ┌→ (raw, برای نمایش)
                          ├→ Calibration → INS → Prediction → Fusion → Estimate → Error Analysis
Trajectory → Truth → GNSS ┴──────────────────────────┘
```

## شروع سریع

```matlab
cd NavSim
main            % راه‌اندازی GUI
```

اجرای تست‌های اعتبارسنجی عددی (بدون GUI):

```matlab
cd NavSim
runAllTests
```

## قابلیت‌ها (نگاشت به الزامات)

| بخش | پیاده‌سازی |
|---|---|
| Trajectory | 9 مسیر: Straight، Circle، FigureEight، Acceleration، Climb، Descent، Turn، Combined3D، UserDefined (عبارت دلخواه `p(t)`) |
| IMU | ژیرو/شتاب‌سنج: Bias، Noise (ARW/VRW)، Scale Factor، Misalignment، Bias Random Walk — همه در Runtime |
| GNSS | نرخ، نویز H/V، بایاس، سرعت، Dropout (برنامه‌ریزی‌شده/تصادفی)، Outlier، Delay |
| INS | مکانیک Strapdown واقعی (Quaternion + انتگرال ذوزنقه‌ای)، پشتیبانی از **dt متغیر** |
| Alignment | Levelling با شتاب‌سنج + قطب‌نما (stub)، خطای اولیه کاربر، نمایش همگرایی |
| Fusion | Error-State EKF با ۱۵ حالت (`δp, δv, δφ, δbg, δba`)، کوپل شل، تصحیح فیدبکی؛ حالت INS Only |
| Error Injection | تب Errors: همه منابع خطا با یک کلیک فعال/غیرفعال |
| Visualization | Position / Velocity / Attitude / Errors / Sensors + نمای 3D (وسیله، محورهای Body و Nav، مسیرها، نقاط GNSS) |
| Real-Time | Start / Pause / Stop / Reset / Step، حالت Real-time و Fast، اسلایدر سرعت |
| Data Flow Monitor | پنل زنده‌ی مراحل + مقادیر فعلی هر مرحله (Gyro, Lat/Lon/Alt, ...) |
| Educational Mode | کلیک روی هر مرحله → توضیح کوتاه: چیست؟ ورودی/خروجی؟ معادله؟ خطاها؟ |
| Experiments | ۱۰ آزمایش آماده با اجرای Headless و مقایسه‌ی آماری |
| Logging | ذخیره MAT/CSV + Replay انیمیشنی |
| Tests | ۷ تست عددی (`runAllTests`) |

## ساختار پوشه‌ها

```
NavSim/
  main.m                  launcher
  startup.m               addpath همه زیرپوشه‌ها
  runAllTests.m           اجرای مجموعه تست
  simulation/             defaultConfig.m, SimEngine.m      (موتور بدون گرافیک)
  trajectory/             TrajectoryLibrary.m
  imu/                    IMUModel.m
  gnss/                   GNSSModel.m
  ins/                    INSMechanization.m
  alignment/              Alignment.m
  fusion/                 LooselyCoupledEKF.m
  visualization/          PlotManager.m, View3D.m
  ui/                     NavSimApp.m, ParamCatalog.m, DataFlowView.m,
                          EduContent.m, ExperimentPresets.m
  logging/                NavLogger.m
  utils/                  quaternion/euler/DCM/LLA/NED + setByPath/getByPath ...
  tests/                  test_*.m
  docs/                   ARCHITECTURE.md, USER_GUIDE.md, EXPERIMENTS.md
```

## مدل و ساده‌سازی‌های آموزشی (شفاف‌سازی)

- فریم ناوبری **NED محلی** (تخت) با تبدیل WGS84 به Lat/Lon/Alt؛ برای منطقه‌ی کوچک معتبر است.
- چرخش زمین و شتاب کوریولیس/ترابرد عمداً نادیده گرفته شده‌اند تا تمرکز روی مکانیک، خطاها و Fusion باشد.
- Heading در Alignment از «قطب‌نمای مغناطیسی» مدل‌شده (چون gyrocompassing بدون چرخش زمین معنادار نیست).
- همگرایی کامل ۱۵-state EKF با سنجش فقط‌موقعیت نیازمند مانور است (قابل مشاهده در Exp 7).

## اعتبارسنجی انجام‌شده

کد متلب زیر **GNU Octave 9.4** واقعاً اجرا شد (`runAllTests` → ۷/۷ سبز) و منطق موتور
همچنین به‌صورت خط‌به‌خط در پایتون (`tools/navsim_mirror.py`) نیز تست شد.
نتایج اجرای واقعی کد متلب (seed=1):

| تست | نتیجه |
|---|---|
| تبدیلات/قراردادها (quat/eul/DCM/LLA) | round-trip < 1e-8 ✅ |
| Perfect match (خطا=0) | max pos err = 0.0003 m، max att err = 0.0002° ✅ |
| Drift ژیرو | رشد ×73 در ۱۲۰ ثانیه ✅ |
| Drift شتاب‌سنج | 706.0 m در برابر تئوری ½bt²=706.0 m ✅ |
| همگرایی EKF | rms pos = 2.71 m، rms att = 0.31°، تخمین بایاس [0.497 −0.304 0.210] در برابر [0.5 −0.3 0.2] deg/s ✅ |
| Alignment | خطای levelling کاهش‌یابنده ✅ |
| dt متغیر | سازگاری با dt ثابت در حد 0.15 m ✅ |
| GNSS Dropout | در قطعی: Fused 55.5 m در برابر INS 1438 m؛ پس از بازگشت: 1.5 m ✅ |

> **INS آزاد موازی**: خروجی «INS» همیشه مسیر drift خام (بدون تصحیح فیلتر) را نشان می‌دهد،
> حتی وقتی Fusion فعال است — مقایسه‌ی زنده‌ی INS در برابر Fused هسته‌ی دمو است.

> دو باگ واقعی در همین فرایند پیدا و اصلاح شد: عدم‌تراز زمانی یک‌گام بین لاگ Truth/INS،
> و علامت جفت‌شدگی بایاس ژیرو در ماتریس F (با قرارداد error = true − est صحیح: `+C·δbg`).

نسخه‌ی متلب مورد نیاز: **R2020b یا جدیدتر** (uifigure/uigridlayout).
اگر متن‌های فارسیِ پنل آموزشی در ویندوز به‌هم‌ریخته دیده شد، Encoding فایل‌ها را UTF-8 نگه دارید.
